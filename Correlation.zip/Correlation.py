"""Import libraries"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn import datasets
"""Import Data Sets from sklearn library"""
housing=datasets.load_boston()

df=pd.DataFrame(housing.data, columns=housing.feature_names)
"""show keys or attributes in the dataset"""
print housing.keys()
"""Statistical Analysis of the Data"""
print df.describe()
"""Print first 5 records"""
print df.head()
"""Give names to column"""
col=['crime','zn','indus','chas','nox','rm','age','dis','rad''tax','ptratio','b','lstat','medv']
df.columns=col
"""Correlation between two variables"""
print df['zn'].corr(df['medv'])
"""Correlation between all variables"""
print df.corr()
"""import seaborn library"""
import seaborn as sns
"""corrlation graphs using seaborn pairplot"""
sns.pairplot(df.corr(), size=1.5)
plt.show()
"""correlation  table using heatmap"""
sns.heatmap(df.corr())
plt.show()
